// Vercel Serverless Function: Google Geocoding + Routes API.
// Configure GOOGLE_MAPS_API_KEY in Vercel Environment Variables.
async function readJson(response, serviceName) {
  const raw = await response.text();
  let data;
  try { data = raw ? JSON.parse(raw) : {}; }
  catch (_) { throw new Error(`${serviceName} retornou uma resposta inválida (HTTP ${response.status}). Verifique a configuração da API.`); }
  if (!response.ok) {
    const detail = data.error?.message || data.error || data.message;
    throw new Error(typeof detail === 'string' ? detail : `${serviceName} apresentou erro HTTP ${response.status}.`);
  }
  return data;
}
async function geocode(address, key) {
  const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${encodeURIComponent(key)}`;
  const response = await fetch(url);
  const data = await readJson(response, 'Google Geocoding');
  if (data.status !== 'OK' || !data.results?.length) {
    throw new Error(`Não foi possível localizar um dos endereços (${data.status || 'sem resultado'}). Confira rua, número, bairro, cidade e CEP.`);
  }
  return data.results[0].geometry.location;
}
module.exports = async function handler(req, res) {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método não permitido.' });
  const key = process.env.GOOGLE_MAPS_API_KEY;
  if (!key) return res.status(503).json({ error: 'Cotação de rota não configurada. Adicione GOOGLE_MAPS_API_KEY nas Environment Variables da Vercel e faça novo deploy.' });
  const body = typeof req.body === 'string' ? (() => { try { return JSON.parse(req.body); } catch (_) { return {}; } })() : (req.body || {});
  const originAddress = String(body.originAddress || '').trim();
  const destinationAddress = String(body.destinationAddress || '').trim();
  if (originAddress.length < 12 || destinationAddress.length < 12 || originAddress.length > 400 || destinationAddress.length > 400) {
    return res.status(400).json({ error: 'Informe os endereços completos da loja e do destino.' });
  }
  try {
    const [origin, destination] = await Promise.all([geocode(originAddress, key), geocode(destinationAddress, key)]);
    const routeResponse = await fetch('https://routes.googleapis.com/directions/v2:computeRoutes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Goog-Api-Key': key, 'X-Goog-FieldMask': 'routes.distanceMeters,routes.duration' },
      body: JSON.stringify({
        origin: { location: { latLng: { latitude: origin.lat, longitude: origin.lng } } },
        destination: { location: { latLng: { latitude: destination.lat, longitude: destination.lng } } },
        travelMode: 'DRIVE', routingPreference: 'TRAFFIC_AWARE', units: 'METRIC'
      })
    });
    const routeData = await readJson(routeResponse, 'Google Routes');
    const route = routeData.routes?.[0];
    if (!route) throw new Error('O Google não encontrou uma rota válida entre os endereços.');
    const duration = String(route.duration || '0s').replace('s', '');
    return res.status(200).json({ distanceMeters: route.distanceMeters, durationSeconds: Number(duration) || 0 });
  } catch (error) {
    console.error('delivery-quote:', error);
    return res.status(400).json({ error: error.message || 'Erro ao calcular a rota.' });
  }
};
