/* Auto Peças da Roque — módulo de entregas */
const DELIVERY_DEFAULTS = {id:1, origin_address:"Rua Roque Barbosa, 16", base_fee:3, first_two_km_fee:4, extra_km_rate:2.5, max_distance_km:null};
let deliverySettings={...DELIVERY_DEFAULTS};
let currentDeliveryQuote=null;
let deliveryOrdersCache=[];
let deliverySubmitting=false;

function updateDeliveryAdminButton(){
  const b=document.getElementById('deliveryAdminButton');
  if(b)b.classList.toggle('hidden',!isAdmin());
}
function onDeliveryTypeChange(){
  const type=document.getElementById('orderDeliveryType')?.value||'delivery';
  document.getElementById('deliveryAddressFields')?.classList.toggle('hidden',type==='pickup');
  document.getElementById('pickupNotice')?.classList.toggle('hidden',type!=='pickup');
  currentDeliveryQuote=null;
  const result=document.getElementById('deliveryQuoteResult'); if(result){result.classList.add('hidden');result.textContent='';}
  updateDeliveryTotals();
}
function clearDeliveryQuote(){
  currentDeliveryQuote=null;
  const result=document.getElementById('deliveryQuoteResult'); if(result){result.classList.add('hidden');result.textContent='';}
  updateDeliveryTotals();
}
function deliveryDestination(){
  const cep=document.getElementById('deliveryCep').value.trim();
  const street=document.getElementById('deliveryStreet').value.trim();
  const number=document.getElementById('deliveryNumber').value.trim();
  const neighborhood=document.getElementById('deliveryNeighborhood').value.trim();
  const city=document.getElementById('deliveryCity').value.trim();
  const complement=document.getElementById('deliveryComplement').value.trim();
  if(!cep||!street||!number||!neighborhood||!city)throw new Error('Preencha CEP, rua, número, bairro e cidade/UF.');
  return {cep,street,number,neighborhood,city,complement,full:[street,number,complement,neighborhood,city,cep,'Brasil'].filter(Boolean).join(', ')};
}
function calculateDeliveryPrice(distanceKm){
  const extra=Math.max(0,Number(distanceKm)-2);
  return Math.round((Number(deliverySettings.base_fee)+Number(deliverySettings.first_two_km_fee)+extra*Number(deliverySettings.extra_km_rate))*100)/100;
}
async function calculateDeliveryQuote(){
  const btn=document.getElementById('calculateDeliveryButton');
  const result=document.getElementById('deliveryQuoteResult');
  try{
    const dest=deliveryDestination();
    if(!deliverySettings.origin_address||deliverySettings.origin_address.trim().length<12)throw new Error('A loja precisa cadastrar o endereço completo de origem no painel administrativo.');
    btn.disabled=true;btn.textContent='Calculando rota...';
    const response=await fetch('/api/delivery-quote',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({originAddress:deliverySettings.origin_address,destinationAddress:dest.full})});
    const data=await response.json();
    if(!response.ok)throw new Error(data.error||'Não foi possível calcular a rota.');
    const km=Math.round(Number(data.distanceMeters)/10)/100;
    const fee=calculateDeliveryPrice(km);
    if(deliverySettings.max_distance_km&&km>Number(deliverySettings.max_distance_km))throw new Error(`Endereço a ${km.toFixed(2).replace('.',',')} km. A distância excede o limite de ${deliverySettings.max_distance_km} km. Entre em contato com a loja.`);
    currentDeliveryQuote={distance_km:km,delivery_fee:fee,duration_seconds:Number(data.durationSeconds)||null,address:dest};
    result.innerHTML=`<div class="font-bold text-green-800">Frete calculado!</div><div>Distância pela rota: <b>${km.toFixed(2).replace('.',',')} km</b></div><div>Valor da entrega: <b class="text-lg text-red-700">${money(fee)}</b></div><div class="text-xs text-gray-600">A modalidade será definida pela loja após o recebimento do pedido.</div>`;
    result.classList.remove('hidden');updateDeliveryTotals();
  }catch(err){currentDeliveryQuote=null;result.textContent=err.message||'Erro ao calcular frete.';result.classList.remove('hidden');result.classList.add('text-red-700');updateDeliveryTotals();}
  finally{btn.disabled=false;btn.textContent='Calcular frete pela distância';}
}
function updateDeliveryTotals(){
  const productsTotal=cart.reduce((sum,item)=>sum+(Number(item.price)||0)*(Number(item.qty)||0),0);
  const type=document.getElementById('orderDeliveryType')?.value||'delivery';
  const fee=type==='pickup'?0:(currentDeliveryQuote?currentDeliveryQuote.delivery_fee:null);
  const productEl=document.getElementById('cartProductsTotal');if(productEl)productEl.textContent=money(productsTotal);
  const feeEl=document.getElementById('cartDeliveryTotal');if(feeEl)feeEl.textContent=fee===null?'A calcular':fee===0?'Grátis':money(fee);
  const totalEl=document.getElementById('cartTotal');if(totalEl)totalEl.textContent=money(productsTotal+(fee||0));
}
const _roqueOriginalUpdateCart=window.updateCart;
window.updateCart=function(){_roqueOriginalUpdateCart();updateDeliveryTotals();};
function toggleCart(){document.getElementById('cartModal').classList.toggle('hidden');updateCart();onDeliveryTypeChange();}

async function loadDeliverySettings(){
  if(!cloudConfigured)return;
  try{
    const r=await fetch(`${SUPABASE_URL}/rest/v1/delivery_settings?select=*&id=eq.1`,{headers:{apikey:SUPABASE_ANON_KEY,Authorization:`Bearer ${SUPABASE_ANON_KEY}`}});
    if(!r.ok)throw new Error(await r.text());
    const rows=await r.json();if(rows.length)deliverySettings={...DELIVERY_DEFAULTS,...rows[0]};
  }catch(e){console.warn('Configurações de entrega ainda não disponíveis. Execute o SQL de instalação.',e);}
}
function openDeliveryAdmin(){
  if(!isAdmin()){document.getElementById('loginModal').classList.remove('hidden');return;}
  document.getElementById('deliveryAdminModal').classList.remove('hidden');
  fillDeliverySettingsForm();loadDeliveryOrders();
}
function closeDeliveryAdmin(){document.getElementById('deliveryAdminModal').classList.add('hidden');}
function fillDeliverySettingsForm(){
  document.getElementById('deliveryOriginAddress').value=deliverySettings.origin_address||'';
  document.getElementById('deliveryBaseFee').value=Number(deliverySettings.base_fee??3).toFixed(2);
  document.getElementById('deliveryFirstTwoFee').value=Number(deliverySettings.first_two_km_fee??4).toFixed(2);
  document.getElementById('deliveryExtraKmRate').value=Number(deliverySettings.extra_km_rate??2.5).toFixed(2);
  document.getElementById('deliveryMaxKm').value=deliverySettings.max_distance_km??'';
}
async function saveDeliverySettings(){
  if(!isAdmin())return toast('Acesso administrativo necessário.');
  const next={origin_address:document.getElementById('deliveryOriginAddress').value.trim(),base_fee:Number(document.getElementById('deliveryBaseFee').value),first_two_km_fee:Number(document.getElementById('deliveryFirstTwoFee').value),extra_km_rate:Number(document.getElementById('deliveryExtraKmRate').value),max_distance_km:document.getElementById('deliveryMaxKm').value===''?null:Number(document.getElementById('deliveryMaxKm').value)};
  if(!next.origin_address||![next.base_fee,next.first_two_km_fee,next.extra_km_rate].every(n=>Number.isFinite(n)&&n>=0)|| (next.max_distance_km!==null&&(!Number.isFinite(next.max_distance_km)||next.max_distance_km<=0)))return toast('Confira o endereço e os valores do frete.');
  try{
    const r=await fetch(`${SUPABASE_URL}/rest/v1/delivery_settings?id=eq.1`,{method:'PATCH',headers:{apikey:SUPABASE_ANON_KEY,Authorization:`Bearer ${adminSession.access_token}`,'Content-Type':'application/json',Prefer:'return=representation'},body:JSON.stringify({...next,updated_at:new Date().toISOString()})});
    if(!r.ok)throw new Error(await r.text());
    deliverySettings={...deliverySettings,...next};toast('Configurações de entrega salvas.');
  }catch(e){console.error(e);toast('Não foi possível salvar. Execute o SQL de instalação e confira as permissões do Supabase.');}
}
function orderStatusLabel(s){return ({pending_admin:'Aguardando definição',courier_requested:'Entregador solicitado',out_for_delivery:'Saiu para entrega',delivered:'Entregue',awaiting_pickup:'Aguardando retirada',picked_up:'Retirado na loja',cancelled:'Cancelado'})[s]||s||'—';}
function deliveryMethodLabel(s){return ({own_motorcycle:'Motoboy próprio',uber_flash:'Uber Flash',pickup:'Retirada na loja'})[s]||'A definir pela loja';}
async function loadDeliveryOrders(){
  const box=document.getElementById('deliveryOrdersList');if(!box)return;
  if(!isAdmin()){box.innerHTML='<p class="text-sm text-red-600">Entre como administrador.</p>';return;}
  box.innerHTML='<p class="text-sm text-gray-500">Carregando pedidos...</p>';
  try{
    const r=await fetch(`${SUPABASE_URL}/rest/v1/delivery_orders?select=*&order=created_at.desc&limit=100`,{headers:{apikey:SUPABASE_ANON_KEY,Authorization:`Bearer ${adminSession.access_token}`}});
    if(!r.ok)throw new Error(await r.text());deliveryOrdersCache=await r.json();renderDeliveryOrders();
  }catch(e){console.error(e);box.innerHTML='<div class="rounded-lg bg-amber-50 p-3 text-sm text-amber-900">Não foi possível carregar os pedidos. Confira se executou o arquivo supabase_delivery_setup.sql no Supabase.</div>';}
}
function renderDeliveryOrders(){
  const box=document.getElementById('deliveryOrdersList');if(!box)return;
  const orders=deliveryOrdersCache;
  document.getElementById('deliveryMetricTotal').textContent=orders.length;
  document.getElementById('deliveryMetricPending').textContent=orders.filter(o=>o.status==='pending_admin').length;
  document.getElementById('deliveryMetricTransit').textContent=orders.filter(o=>o.status==='courier_requested'||o.status==='out_for_delivery').length;
  document.getElementById('deliveryMetricDone').textContent=orders.filter(o=>o.status==='delivered'||o.status==='picked_up').length;
  if(!orders.length){box.innerHTML='<div class="border border-dashed rounded-xl p-6 text-center text-sm text-gray-500">Nenhum pedido registrado ainda.</div>';return;}
  box.innerHTML=orders.map(o=>{
    const address=o.delivery_type==='pickup'?'Retirada na loja':(o.destination_address||'Endereço não informado');
    const products=Array.isArray(o.products)?o.products.map(p=>`${safe(p.qty)}x ${safe(p.name)}`).join('<br>'):'Itens do pedido';
    const methods=o.delivery_type==='pickup'?'<option value="pickup" selected>Retirada na loja</option>':'<option value="" disabled '+(!o.delivery_method?'selected':'')+'>Escolher modalidade</option><option value="own_motorcycle" '+(o.delivery_method==='own_motorcycle'?'selected':'')+'>Motoboy próprio</option><option value="uber_flash" '+(o.delivery_method==='uber_flash'?'selected':'')+'>Uber Flash</option>';
    const statuses=['pending_admin','courier_requested','out_for_delivery','delivered','awaiting_pickup','picked_up','cancelled'];
    const statusOptions=statuses.map(st=>`<option value="${st}" ${o.status===st?'selected':''}>${orderStatusLabel(st)}</option>`).join('');
    return `<article class="border rounded-xl p-3 md:p-4"><div class="flex flex-wrap justify-between gap-2"><div><b>Pedido #${o.id}</b><div class="text-xs text-gray-500">${new Date(o.created_at).toLocaleString('pt-BR')}</div></div><span class="text-xs font-bold rounded-full bg-gray-100 px-3 py-1">${orderStatusLabel(o.status)}</span></div><div class="grid md:grid-cols-2 gap-3 mt-3 text-sm"><div><b>${safe(o.customer_name)}</b><div>${safe(o.customer_phone)}</div><div class="text-xs text-gray-500">Pagamento: ${safe(o.payment_method||'A combinar')}</div><div class="text-gray-600 mt-1">${safe(address)}</div><div class="text-xs text-gray-500 mt-1">${o.distance_km?`${Number(o.distance_km).toFixed(2)} km · `:''}${deliveryMethodLabel(o.delivery_method)}</div></div><div class="text-sm">${products}<div class="mt-2 text-gray-600">Produtos: ${money(Number(o.products_total)||0)} · Frete: ${money(Number(o.delivery_fee)||0)}</div><b class="text-red-700">Total: ${money(Number(o.grand_total)||0)}</b></div></div><div class="grid md:grid-cols-3 gap-2 mt-3"><label class="text-xs font-semibold">Modalidade<select id="deliveryMethod-${o.id}" class="w-full border rounded-lg p-2 mt-1" ${o.delivery_type==='pickup'?'disabled':''}>${methods}</select></label><label class="text-xs font-semibold">Status<select id="deliveryStatus-${o.id}" class="w-full border rounded-lg p-2 mt-1">${statusOptions}</select></label><div class="flex items-end"><button onclick="updateDeliveryOrder(${o.id})" class="w-full bg-red-600 text-white rounded-lg p-2 font-bold">Salvar pedido</button></div></div></article>`;
  }).join('');
}
async function updateDeliveryOrder(id){
  if(!isAdmin())return toast('Acesso administrativo necessário.');
  const order=deliveryOrdersCache.find(o=>Number(o.id)===Number(id));if(!order)return;
  const method=document.getElementById(`deliveryMethod-${id}`).value;
  const status=document.getElementById(`deliveryStatus-${id}`).value;
  if(order.delivery_type==='delivery'&&!['own_motorcycle','uber_flash'].includes(method))return toast('Escolha o entregador.');
  try{
    const r=await fetch(`${SUPABASE_URL}/rest/v1/delivery_orders?id=eq.${encodeURIComponent(id)}`,{method:'PATCH',headers:{apikey:SUPABASE_ANON_KEY,Authorization:`Bearer ${adminSession.access_token}`,'Content-Type':'application/json',Prefer:'return=minimal'},body:JSON.stringify({delivery_method:method,status,updated_at:new Date().toISOString()})});
    if(!r.ok)throw new Error(await r.text());toast('Pedido atualizado.');await loadDeliveryOrders();
  }catch(e){console.error(e);toast('Não foi possível atualizar o pedido.');}
}
async function sendOrder(phone){
  if(deliverySubmitting)return;
  if(!cart.length){toast('Adicione itens ao carrinho.');return;}
  const customerName=document.getElementById('orderCustomerName').value.trim();
  const customerPhone=document.getElementById('orderCustomerPhone').value.trim();
  const deliveryType=document.getElementById('orderDeliveryType').value;
  if(!customerName||!customerPhone){toast('Informe seu nome e telefone.');return;}
  let address=null,km=null,fee=0;
  if(deliveryType==='delivery'){
    if(!currentDeliveryQuote){toast('Calcule o frete antes de enviar o pedido.');return;}
    try{address=deliveryDestination();}catch(e){toast(e.message);return;}
    km=currentDeliveryQuote.distance_km;fee=currentDeliveryQuote.delivery_fee;
  }
  const productsTotal=cart.reduce((sum,item)=>sum+(Number(item.price)||0)*(Number(item.qty)||0),0);
  const grandTotal=Math.round((productsTotal+fee)*100)/100;
  const payment=document.getElementById('orderPayment')?.value||'A combinar';
  const items=cart.map(item=>({product_id:item.id,name:String(item.name||'Produto'),part_code:item.partCode||'',qty:Math.max(1,Number(item.qty)||1),unit_price:Number(item.price)||0,subtotal:(Number(item.price)||0)*Math.max(1,Number(item.qty)||1)}));
  const destination=address?address.full:null;
  const payload={customer_name:customerName,customer_phone:customerPhone,delivery_type:deliveryType,destination_address:destination,postal_code:address?.cep||null,distance_km:km,delivery_fee:fee,products:items,products_total:productsTotal,grand_total:grandTotal,payment_method:payment,delivery_method:deliveryType==='pickup'?'pickup':null,status:deliveryType==='pickup'?'awaiting_pickup':'pending_admin'};
  const lines=items.map((item,index)=>`${index+1}) ${item.name}${item.part_code?' ('+item.part_code+')':''}\n   Quantidade: ${item.qty}\n   Unitário: ${money(item.unit_price)}\n   Subtotal: ${money(item.subtotal)}`);
  const msg=['*NOVO PEDIDO - AUTO PEÇAS DA ROQUE*','📍 Rua Roque Barbosa, 16','',`*CLIENTE: ${customerName}*`,`*TELEFONE: ${customerPhone}*`,'','*PRODUTOS:*',...lines,'',`*PRODUTOS: ${money(productsTotal)}*`,deliveryType==='pickup'?'*ENTREGA: RETIRADA NA LOJA — GRÁTIS*':`*ENDEREÇO: ${destination}*\n*DISTÂNCIA: ${km.toFixed(2)} km*\n*FRETE: ${money(fee)}*\n*MODALIDADE: A DEFINIR PELA LOJA (MOTOBOY OU UBER FLASH)*`,`*TOTAL: ${money(grandTotal)}*`,`*FORMA DE PAGAMENTO: ${payment}*`,'','Olá! Gostaria de confirmar meu pedido.'].join('\n');
  const waUrl=`https://wa.me/${String(phone).replace(/\D/g,'')}?text=${encodeURIComponent(msg)}`;
  const waWindow=window.open('about:blank','_blank');
  if(!waWindow){toast('Permita a abertura de janelas para enviar o pedido pelo WhatsApp.');return;}
  deliverySubmitting=true;
  try{
    const r=await fetch(`${SUPABASE_URL}/rest/v1/delivery_orders`,{method:'POST',headers:{apikey:SUPABASE_ANON_KEY,Authorization:`Bearer ${SUPABASE_ANON_KEY}`,'Content-Type':'application/json',Prefer:'return=minimal'},body:JSON.stringify(payload)});
    if(!r.ok)throw new Error(await r.text());
    waWindow.location.href=waUrl;
    toast('Pedido registrado! Abrindo WhatsApp.');
    cart=[];updateCart();document.getElementById('cartModal').classList.add('hidden');
  }catch(e){console.error(e);waWindow.close();toast('Não foi possível registrar o pedido. Confira a instalação do módulo no Supabase.');}
  finally{deliverySubmitting=false;}
}

// Keep the existing product/admin experience and add the delivery controls.
const _roqueOriginalLoginAdmin=window.loginAdmin;
window.loginAdmin=async function(e){await _roqueOriginalLoginAdmin(e);updateDeliveryAdminButton();};
const _roqueOriginalAdminLogout=window.adminLogout;
window.adminLogout=function(){_roqueOriginalAdminLogout();updateDeliveryAdminButton();};
document.addEventListener('DOMContentLoaded',async()=>{
  updateDeliveryAdminButton();
  await loadDeliverySettings();
  onDeliveryTypeChange();
});
